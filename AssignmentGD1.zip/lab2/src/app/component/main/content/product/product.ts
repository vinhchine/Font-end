export class Product {
    productID: number;
    productName: string;
    priceSale: string;
    status: boolean;
    imagePath: string;
    newPrice: string;
}
